package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView res;
    private EditText numero1;
    private EditText numero2;
    private Button btnSoma;
    //criando as outras variaveis para os botões
    private Button btnSub;
    private Button btnDiv;
    private Button btnMult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        res = findViewById(R.id.resultado);
        numero1 = findViewById(R.id.editNumero1);
        numero2 = findViewById(R.id.editNumero2);
        btnSoma = findViewById(R.id.somaBtn);

        //populando outras variaveis dos botões
        btnSub = findViewById(R.id.subBtn);
        btnDiv = findViewById(R.id.divisaoBtn);
        btnMult = findViewById(R.id.multiplicacaoBtn);

        //métodos para os botões
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(String.valueOf(numero1.getText())); //Muitas Conversões
                int n2 = Integer.parseInt(String.valueOf(numero2.getText()));
                int resultSoma = n1 + n2;
                res.setText("Resultado: " + resultSoma);
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(String.valueOf(numero1.getText()));
                int n2 = Integer.parseInt(String.valueOf(numero2.getText()));
                int resultSub = n1 - n2;
                res.setText("Resultado: " + resultSub);

            }
        });

        btnMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(String.valueOf(numero1.getText()));
                int n2 = Integer.parseInt(String.valueOf(numero2.getText()));
                int resultMult = n1 * n2;
                res.setText("Resultado: " + resultMult);
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(String.valueOf(numero1.getText()));
                int n2 = Integer.parseInt(String.valueOf(numero2.getText()));
                int resultDiv = n1 / n2;
                res.setText("Resultado: " + resultDiv);
            }
        });
    }
}